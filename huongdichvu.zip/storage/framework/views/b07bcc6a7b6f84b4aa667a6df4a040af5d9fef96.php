<?php $__env->startSection('content'); ?>
	<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Sản phẩm</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <?php if(session('thongbao')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('thongbao')); ?>

                </div>
            <?php endif; ?>
            <div class="row">
                <p>Tên sản phẩm : <?php echo e($product->product_name); ?></p>
                <p>Giá sản phẩm : <?php echo e($product->product_price); ?></p>
                <p>Số lượng sản phẩm :<?php echo e($product->product_quantity); ?></p>
                <p><img width="300px" src="upload/product/<?php echo e($product->product_image); ?>"></p>
            	<p>Id Thể loại : <?php echo e($product->product_category_id); ?></p>
                <p>Note : <?php echo e($product->product_note); ?></p>
                <p>Hiển thị : <?php echo e($product->product_enable); ?></p>
                <p>Mô tả : <?php echo e($product->product_description); ?></p>
                <p>Mã nhà cung cấp : <?php echo e($product->product_provider_id); ?></p>
                <p>Thông tin sản phẩm : <?php echo e($product->product_content); ?></p>
                <p>Ngày sản xuất : <?php echo e($product->product_manufacturing_date); ?></p>
                <p>Hạn sử dụng : <?php echo e($product->product_expiry_date); ?></p>
            </div>
            <!-- /.row -->
    </div>
    <!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>