<?php $__env->startSection('content'); ?>
	<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Người dùng</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <?php if(session('thongbao')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('thongbao')); ?>

                </div>
            <?php endif; ?>
            <div class="row">
                <p>Tên người dùng : <?php echo e($user->user_name); ?></p>
                <p>Email : <?php echo e($user->user_email); ?></p>
                <p>Địa chỉ : <?php echo e($user->user_address); ?></p>
                <p>Image :<img width="300px" src="upload/user/<?php echo e($user->user_image); ?>"></p>
                <p>Quyền : <?php echo e($user->user_level); ?></p>
                <p>Giới tính : <?php echo e($user->user_gender); ?></p>
                <p>Số điện thoại : <?php echo e($user->user_phone); ?></p>
                <p>Tuổi : <?php echo e($user->user_age); ?></p>
                <p>Note : <?php echo e($user->user_note); ?></p>
            </div>
            <!-- /.row -->
    </div>
    <!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>