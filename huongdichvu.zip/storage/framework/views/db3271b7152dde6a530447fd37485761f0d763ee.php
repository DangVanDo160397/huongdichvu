<?php $__env->startSection('content'); ?>
	<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Câu hỏi</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <?php if(session('thongbao')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('thongbao')); ?>

                </div>
            <?php endif; ?>
            <div class="row">
                <p>Mã người hỏi : <?php echo e($question->question_user_id); ?></p>
                <p>Mã chuyên gia : <?php echo e($question->question_expert_id); ?></p>
            	<p>Câu hỏi : <?php echo e($question->question_name); ?></p>
                <p>Trả lời : <?php echo e($question->question_content); ?></p>
            </div>
            <!-- /.row -->
    </div>
    <!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>