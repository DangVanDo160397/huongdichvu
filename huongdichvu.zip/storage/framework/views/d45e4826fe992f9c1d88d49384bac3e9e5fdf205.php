<?php $__env->startSection('content'); ?>
	<div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">NCC
                            <small>Sửa</small>
                        </h1>
                    </div>
                    <!-- /.col-lg-12 -->

                    <div class="col-lg-7" style="padding-bottom:120px">
                    	<?php if(count($errors) > 0): ?>
                    		<div class="alert alert-danger">
                    			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    				<?php echo e($err); ?> <br>
                    			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    		</div>
                    	<?php endif; ?>
                        <form action="<?php echo e(route('provider.update',$provider)); ?>" method="POST">
                        	<?php echo e(csrf_field()); ?> <?php echo e(method_field('PUT')); ?>

                            <div class="form-group">
                                <label>Tên NCC</label>
                                <input class="form-control" name="name" value="<?php echo e($provider->name); ?>" placeholder="Mời nhập tên thể loại" />
                            </div>
                            <div class="form-group">
                                <label>Địa chỉ</label>
                                <input class="form-control" name="address" value="<?php echo e($provider->address); ?>" placeholder="Mời nhập tên thể loại" />
                            </div>
                            <div class="form-group">
                                <label>Số điện thoại</label>
                                <input class="form-control" name="phone" value="<?php echo e($provider->phone); ?>" placeholder="Mời nhập tên thể loại" />
                            </div>
                            <button type="submit" class="btn btn-default">Sửa</button>
                            <button type="reset" class="btn btn-default">Làm mới</button>
                        <form>
                    </div>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>